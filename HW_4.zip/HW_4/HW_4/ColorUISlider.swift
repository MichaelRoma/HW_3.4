//
//  ColorUISlider.swift
//  HW_4
//
//  Created by Mykhailo Romanovskyi on 02.08.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import SwiftUI

struct ColorUISlider: UIViewRepresentable {
    
    @Binding var value: Double
    var color: UIColor
    
    func makeUIView(context: Context) -> UISlider {
        let slider = UISlider()
        slider.minimumValue = 0
        slider.maximumValue = 200
        
        slider.thumbTintColor = color
        slider.value = Float(value)
        slider.addTarget(context.coordinator,
                         action: #selector(Coordinator.valueChange),
                         for: .valueChanged)
        return slider
    }
    
    func updateUIView(_ uiView: UISlider, context: Context) {
        uiView.value = Float(value)
    }
    func makeCoordinator() -> ColorUISlider.Coordinator {
        Coordinator(value: $value)
    }
}

extension ColorUISlider {
    class Coordinator: NSObject {
        @Binding var value: Double
        init(value: Binding<Double>) {
            self._value = value
        }
        @objc func valueChange(_ sender: UISlider) {
            value = Double(sender.value)
        }
    }
}

struct ColorUISlider_Previews: PreviewProvider {
    static var previews: some View {
        ColorUISlider(value: .constant(100), color: .red)
    }
    
    
}

