//
//  ContentView.swift
//  HW_4
//
//  Created by Mykhailo Romanovskyi on 02.08.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    //Диапазон в слайдере меньше для того чтоб ползунок был примерно в середине
    @State private var sliderValue = Double.random(in: 50...150)
    @State private var targetValue = Int.random(in: 0...200)
    @State private var showAlert = false
    
    var body: some View {
        
        VStack {
            Text("Подвиньте слайдер как можно ближе к: \(targetValue)")
                .font(.title)
                .lineLimit(1)
                .minimumScaleFactor(0.5)
            
            HStack {
                Text("0")
                ColorUISlider(value: $sliderValue, color: .red)
                    .opacity(opacityForSlider())
                    .accentColor(.red)
                Text("200")
            }
            
            Button(action: { self.showAlert = true }) {
                Text("Проверь меня")
            }.padding()
                .alert(isPresented: $showAlert) {
                    Alert(
                        title: Text("Your Score"),
                        message: Text("\(computeScore())"),
                        dismissButton: .default(Text("OK")){ self.showAlert = false } )
            }
            
            Button(action: startNewGame)  {
                Text("Начать заново")
            }
        }
        .padding()
    }
}

extension ContentView {
    private func startNewGame() {
        self.sliderValue = Double.random(in: 0...200)
        self.targetValue = Int.random(in: 0...200)
    }
    
    private func opacityForSlider() -> Double {
        if sliderValue < Double(targetValue) {
            return (sliderValue + 10) / Double(targetValue)
        } else {
            return (200 - sliderValue + 10)/(200 - Double(targetValue))
        }
    }
    
    private func computeScore() -> Int {
        let difference = abs(targetValue - lround(sliderValue))
        return 100 - difference
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
